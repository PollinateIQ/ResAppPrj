from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from models import app, db, MenuItem, Order

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/table_locator')
def table_locator():
    # Add any server-side logic needed for the table locator feature
    return render_template('table_locator.html')

@app.route('/menu')
def menu():
    menu_items = MenuItem.query.all()
    return render_template('menu.html', menu_items=menu_items)


@app.route('/order', methods=['POST'])
def order():
    menu_item_id = request.form.get('menu_item_id')  # The ID of the item the user wants to order
    new_order = Order(menu_item_id=menu_item_id)
    db.session.add(new_order)
    db.session.commit()
    return redirect(url_for('order_tracker', order_id=new_order.id))
#Add the following route to app.py


@app.route('/place_order', methods=['POST'])
def place_order():
    # Get the form data from the request
    order_data = request.form
    # Process the order data...
    return "Order placed successfully!"

@app.route('/payment')
def payment():
    # Add any server-side logic needed for the payment feature
    return render_template('payment.html')

@app.route('/pay', methods=['POST'])
def pay():
    order_id = request.form.get('order_id')  # The ID of the order the user wants to pay for
    order = Order.query.get(order_id)
    order.status = 'Paid'
    db.session.commit()
    return redirect(url_for('order_tracker', order_id=order_id))



@app.route('/process_payment', methods=['POST'])
def process_payment():
    # Get the form data from the request
    payment_data = request.form
    # Process the payment data...
    return "Payment processed successfully!"

@app.route('/order_tracker')
def order_tracker():
    order_id = request.args.get('order_id')  # The ID of the order the user wants to track
    order = Order.query.get(order_id)
    return render_template('order_tracker.html', order=order)

@app.route('/feedback')
def feedback():
    # Add any server-side logic needed for the feedback feature
    return render_template('feedback.html')

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    # Get the form data from the request
    feedback_data = request.form
    # Process the feedback data...
    return "Feedback submitted successfully!"

if __name__ == '__main__':
    app.run(debug=True)
    
@app.before_first_request
def create_tables():
    db.create_all()

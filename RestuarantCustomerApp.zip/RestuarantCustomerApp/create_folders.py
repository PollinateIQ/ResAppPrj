import os

# Define the directories to be created
folders_to_create = ["templates", "static/css", "static/js", "static/img"]

for folder in folders_to_create:
    try:
        os.makedirs(folder)
    except OSError:
        print ("Creation of the directory %s failed" % folder)
    else:
        print ("Successfully created the directory %s" % folder)

# Define the files to be created
files_to_create = [
    "templates/home.html", 
    "templates/table_locator.html",
    "templates/menu.html",
    "templates/order.html",
    "templates/payment.html",
    "templates/order_tracker.html",
    "templates/feedback.html"
]

for file in files_to_create:
    try:
        open(file, 'a').close()
    except OSError:
        print ("Creation of the file %s failed" % file)
    else:
        print ("Successfully created the file %s" % file)
